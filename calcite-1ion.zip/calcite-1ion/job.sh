#!/bin/bash
#SBATCH --account=d64
#SBATCH --partition=workq
#SBATCH --time=24:00:00
#SBATCH --nodes=60
#SBATCH --ntasks-per-node=24
#SBATCH --no-requeue
#SBATCH --export=ALL
#SBATCH --job-name=Ac_co3_s1

cd $SLURM_SUBMIT_DIR
nfile=lammps
nn=`ls $nfile.*.log | grep -c $nfile`
mm=$((nn-1))

nruns=4
nr=$((nruns-1))

if [ $nn -ge $nruns  ] ; then
  exit
fi
if [ $nn -lt $nr  ] ; then
  sbatch --dependency=afterany:$SLURM_JOB_ID job.sh
fi

# run lammps
lmp=/home/paolo/Programs_magnus/lammps-git/src/lmp_magnus_gnu_s
aprun -B $lmp -screen none -log lammps.${nn}.log -in lammps.inp -partition 30x48 -var run_no ${nn}
